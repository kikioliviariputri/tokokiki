<?php
session_start();
include('config/koneksi.php'); // Pastikan sudah koneksi DB

// Cek jika user sudah login
if (!isset($_SESSION['user_id'])) {
    $_SESSION['notif'] = "Silakan login terlebih dahulu untuk mengakses keranjang.";
    header("Location: login.php");
    exit();
}

print($id_buku);
die();
// Ambil data dari form
$id_buku = $_POST['id_buku'];
$nama_buku = $_POST['nama_buku'];
$harga = $_POST['harga'];
$jumlah = $_POST['jumlah'];

// Cek apakah sudah ada produk yang sama di keranjang
if (isset($_SESSION['keranjang'][$id_buku])) {
    // Jika ada, tambahkan jumlah produk yang sama
    $_SESSION['keranjang'][$id_buku]['jumlah'] += $jumlah;
} else {
    // Jika tidak ada, tambah produk baru
    $_SESSION['keranjang'][$id_buku] = [
        'nama_buku' => $nama_buku,
        'harga' => $harga,
        'jumlah' => $jumlah
    ];
}

// Redirect ke halaman keranjang atau halaman lain
header("Location: cart.php");
exit();
?>
