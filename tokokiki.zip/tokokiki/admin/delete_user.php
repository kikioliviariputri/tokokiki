<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

include '../config/koneksi.php';

// Pastikan ada ID yang diterima untuk dihapus
if (isset($_GET['user_id'])) {
    $user_id = $_GET['user_id'];

    // Pastikan ID yang diterima adalah angka
    if (is_numeric($user_id)) {
        $query = "DELETE FROM users WHERE user_id = $user_id";
        if (mysqli_query($conn, $query)) {
            echo "<script>alert('Pengguna berhasil dihapus'); window.location.href='users.php';</script>";
        } else {
            echo "<script>alert('Terjadi kesalahan saat menghapus pengguna'); window.location.href='users.php';</script>";
        }
    } else {
        echo "<script>alert('ID tidak valid'); window.location.href='users.php';</script>";
    }
} else {
    echo "<script>alert('ID pengguna tidak ditemukan'); window.location.href='users.php';</script>";
}
?>
