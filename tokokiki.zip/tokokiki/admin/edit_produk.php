<?php
session_start();
include('../config/koneksi.php');

// Cek apakah user sudah login dan memiliki role admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Ambil id_buku dari query string
if (!isset($_GET['id_buku'])) {
    header("Location: produk.php");
    exit();
}

$id_buku = $_GET['id_buku'];

// Query untuk mendapatkan data produk berdasarkan id_buku
$query = mysqli_query($conn, "SELECT * FROM produk WHERE id_buku = '$id_buku'");
$product = mysqli_fetch_assoc($query);

// Ambil daftar kategori
$kategori_query = mysqli_query($conn, "SELECT * FROM kategori");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil data form
    $nama_buku = mysqli_real_escape_string($conn, $_POST['nama_buku']);
    $penerbit = mysqli_real_escape_string($conn, $_POST['penerbit']);
    $harga = mysqli_real_escape_string($conn, $_POST['harga']);
    $stok = mysqli_real_escape_string($conn, $_POST['stok']);
    $kategori_id = mysqli_real_escape_string($conn, $_POST['kategori_id']);
    
    // Cek apakah gambar baru diupload
    $gambar = $product['gambar']; // Jika tidak ada gambar baru, gunakan gambar lama
    if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] == 0) {
        $gambar_name = $_FILES['gambar']['name'];
        $gambar_tmp_name = $_FILES['gambar']['tmp_name'];
        $gambar_ext = pathinfo($gambar_name, PATHINFO_EXTENSION);
        $gambar_new_name = 'produk_' . time() . '.' . $gambar_ext;

        // Direktori upload
        $upload_dir = '../uploads/';
        $upload_file = $upload_dir . $gambar_new_name;

        // Cek ekstensi gambar
        $allowed_ext = ['jpg', 'jpeg', 'png', 'gif'];
        if (in_array(strtolower($gambar_ext), $allowed_ext)) {
            move_uploaded_file($gambar_tmp_name, $upload_file);
            $gambar = $gambar_new_name;
        } else {
            echo "<script>alert('Format gambar tidak valid!');</script>";
        }
    }

    // Query untuk update produk
    $updateQuery = "UPDATE produk SET 
                    nama_buku = '$nama_buku',
                    penerbit = '$penerbit',
                    harga = '$harga',
                    stok = '$stok',
                    kategori_id = '$kategori_id',
                    gambar = '$gambar'
                    WHERE id_buku = '$id_buku'";
    
    if (mysqli_query($conn, $updateQuery)) {
        echo "<script>alert('Produk berhasil diperbarui!');</script>";
        header("Location: produk.php"); // Redirect ke halaman daftar produk
    } else {
        echo "<script>alert('Terjadi kesalahan saat memperbarui produk.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Edit Produk</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
  <?php include 'include/sidebar.php'; ?>
  <div class="w-100">
    <?php include 'include/header.php'; ?>
<div class="container">
    <div class="content">
      <h2 class="mb-4">Edit Produk</h2>

      <form action="edit_produk.php?id_buku=<?php echo $id_buku; ?>" method="POST" enctype="multipart/form-data">
        <div class="mb-3">
          <label for="nama_buku" class="form-label">Nama Buku</label>
          <input type="text" class="form-control" id="nama_buku" name="nama_buku" value="<?php echo $product['nama_buku']; ?>" required>
        </div>
        <div class="mb-3">
          <label for="penerbit" class="form-label">Penerbit</label>
          <input type="text" class="form-control" id="penerbit" name="penerbit" value="<?php echo $product['penerbit']; ?>" required>
        </div>
        <div class="mb-3">
          <label for="harga" class="form-label">Harga</label>
          <input type="number" class="form-control" id="harga" name="harga" value="<?php echo $product['harga']; ?>" required>
        </div>
        <div class="mb-3">
          <label for="stok" class="form-label">Stok</label>
          <input type="number" class="form-control" id="stok" name="stok" value="<?php echo $product['stok']; ?>" required>
        </div>
        <div class="mb-3">
          <label for="kategori_id" class="form-label">Kategori</label>
          <select class="form-control" id="kategori_id" name="kategori_id" required>
            <option value="">Pilih Kategori</option>
            <?php while ($kategori = mysqli_fetch_assoc($kategori_query)) { ?>
              <option value="<?php echo $kategori['id_kategori']; ?>" <?php echo $kategori['id_kategori'] == $product['kategori_id'] ? 'selected' : ''; ?>><?php echo $kategori['nama_kategori']; ?></option>
            <?php } ?>
          </select>
        </div>
        <div class="mb-3">
          <label for="gambar" class="form-label">Gambar Produk</label>
          <input type="file" class="form-control" id="gambar" name="gambar" accept="image/*">
          <img src="../img/uploads/<?php echo $product['gambar']; ?>" width="100" class="mt-3">
        </div>
        <button type="submit" class="btn btn-primary">Update Produk</button>
      </form>
    </div>
  </div>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
