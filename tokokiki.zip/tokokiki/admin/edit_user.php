<?php
session_start();
include('../config/koneksi.php');

// Cek apakah user sudah login dan memiliki role admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Ambil id_user dari parameter URL
if (isset($_GET['user_id'])) {
    $user_id = $_GET['user_id'];

    // Ambil data user berdasarkan id_user
    $query = "SELECT * FROM users WHERE user_id = '$user_id'";
    $result = mysqli_query($conn, $query);
    
    // Cek apakah data user ditemukan
    if (mysqli_num_rows($result) == 0) {
        echo "<script>alert('User tidak ditemukan!'); window.location.href = 'list_users.php';</script>";
        exit();
    }
    
    // Ambil data user
    $user = mysqli_fetch_assoc($result);

    // Update data user
    if (isset($_POST['update'])) {
        $username = mysqli_real_escape_string($conn, $_POST['username']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $role = mysqli_real_escape_string($conn, $_POST['role']);

        // Query untuk update user
        $updateQuery = "UPDATE users SET username='$username', email='$email', role='$role' WHERE user_id='$id_user'";
        if (mysqli_query($conn, $updateQuery)) {
            echo "<script>alert('User berhasil diperbarui!'); window.location.href = 'users.php';</script>";
        } else {
            echo "<script>alert('Terjadi kesalahan saat memperbarui user.');</script>";
        }
    }
} else {
    echo "<script>alert('ID user tidak ditemukan!'); window.location.href = 'users.php';</script>";
    exit();
}

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit User</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <?php include 'include/sidebar.php'; ?>
    <div class="w-100">
        <?php include 'include/header.php'; ?>
        <div class="container mt-4">
            <h2>Edit User</h2>

            <form action="" method="POST">
                <div class="mb-3">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" class="form-control" id="username" name="username" value="<?= htmlspecialchars($user['username']) ?>" required>
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>
                </div>
                <div class="mb-3">
                    <label for="role" class="form-label">Role</label>
                    <select class="form-select" id="role" name="role" required>
                        <option value="admin" <?= $user['role'] == 'admin' ? 'selected' : '' ?>>Admin</option>
                        <option value="user" <?= $user['role'] == 'user' ? 'selected' : '' ?>>User</option>
                    </select>
                </div>
                <button type="submit" name="update" class="btn btn-primary">Update</button>
            </form>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
