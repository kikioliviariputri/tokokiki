<?php
// Pastikan session sudah aktif
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>

<div class="d-flex justify-content-between align-items-center px-4 py-3 border-bottom bg-white shadow-sm" style="margin-left: 250px;">
  <h4 class="mb-0">Toko Buku Kiki - Admin</h4>

  <div class="dropdown">
    <button class="btn btn-outline-secondary dropdown-toggle" type="button" id="dropdownUser" data-bs-toggle="dropdown" aria-expanded="false">
      <i class="bi bi-person-circle"></i> <?php echo $_SESSION['username']; ?>
    </button>
    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="dropdownUser">
      <li><a class="dropdown-item" href="#">Profil</a></li>
      <li><a class="dropdown-item" href="../logout.php">Logout</a></li>
    </ul>
  </div>
</div>
