<!-- Tambahkan link ke Font Awesome di <head> halaman utama jika belum -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<div class="sidebar bg-dark text-white p-3" style="width: 250px; min-height: 100vh; position: fixed;">
  <h5 class="text-white mb-4"><i class="fas fa-book"></i> Admin Panel</h5>
  <ul class="nav flex-column">
    <li class="nav-item">
      <a href="index.php" class="nav-link text-white">
        <i class="fas fa-home me-2"></i> Dashboard
      </a>
    </li>

    <li class="nav-item mt-3 fw-bold text-white-50">Manajemen Produk</li>
    <li class="nav-item">
      <a href="produk.php" class="nav-link text-white">
        <i class="fas fa-book-open me-2"></i> Daftar Produk
      </a>
    </li>
    <li class="nav-item">
      <a href="tambah_produk.php" class="nav-link text-white">
        <i class="fas fa-plus me-2"></i> Tambah Produk
      </a>
    </li>
    <li class="nav-item">
      <a href="kategori.php" class="nav-link text-white">
        <i class="fas fa-tags me-2"></i> Kategori
      </a>
    </li>

    <li class="nav-item mt-3 fw-bold text-white-50">Laporan</li>
    <li class="nav-item">
      <a href="users.php" class="nav-link text-white">
        <i class="fas fa-chart-line me-2"></i> Daftar Pengguna
      </a>
    </li>
    <li class="nav-item">
      <a href="penjualan_list.php" class="nav-link text-white">
        <i class="fas fa-box me-2"></i> Daftar Penjualan
      </a>
    </li>

    <li class="nav-item mt-3">
      <a href="../logout.php" class="nav-link text-danger">
        <i class="fas fa-sign-out-alt me-2"></i> Logout
      </a>
    </li>
  </ul>
</div>
