    <?php
    session_start();
    include('../config/koneksi.php'); // koneksi DB
    $cek=$_SESSION['user_id'];
    // Cek jika session user_id ada
    if (!isset($_SESSION['user_id'])) {
        // Jika tidak ada session, arahkan ke halaman login
        header("Location: ../login.php");
        exit();
    }

    // Ambil user dari database untuk validasi role
    $user_id = $_SESSION['user_id'];
    $query = mysqli_query($conn, "SELECT role FROM users WHERE user_id = '$user_id'"); // Perbaiki penggunaan 'id' sesuai dengan kolom di tabel
    $user = mysqli_fetch_assoc($query);

    // Pastikan hanya admin yang bisa mengakses halaman ini
    if (!$user || $user['role'] !== 'admin') {
        // Jika bukan admin, arahkan ke halaman login
        header("Location: ../login.php");
        exit();
    }

    // Hitung total pengguna
    $resultUsers = mysqli_query($conn, "SELECT COUNT(*) AS total_users FROM users");
    $totalUsers = mysqli_fetch_assoc($resultUsers)['total_users'];

    // Hitung total penjualan
    $resultSales = mysqli_query($conn, "SELECT SUM(jumlah_terjual) AS total_sales FROM penjualan");
    $totalSales = mysqli_fetch_assoc($resultSales)['total_sales'] ?: 0; // Pastikan jika null menjadi 0

    // Hitung total penghasilan
    $resultIncome = mysqli_query($conn, "SELECT SUM(total_harga) AS total_income FROM penjualan");
    $totalIncome = mysqli_fetch_assoc($resultIncome)['total_income'] ?: 0; // Pastikan jika null menjadi 0

    // Buku terlaris bulan ini
    $currentMonth = date('m');
    $resultBestSellers = mysqli_query($conn, "
        SELECT produk.nama_buku, SUM(penjualan.jumlah_terjual) AS total_terjual
        FROM penjualan
        JOIN produk ON penjualan.id_buku = produk.id_buku
        WHERE MONTH(tanggal_penjualan) = '$currentMonth'
        GROUP BY produk.id_buku
        ORDER BY total_terjual DESC
        LIMIT 5
    ");
    ?>

    <!DOCTYPE html>
    <html lang="en">
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>

    </head>
    <body>
    <?php include('include/sidebar.php');?>
     <div class="w-100">
    <?php include 'include/header.php'; ?>
    
    <!-- Main Content -->
    <div class="content">
<div class="container">
        <h2 class="mb-4 fw-bold">Selamat Datang di Dashboard Admin</h2>

        <div class="row mb-5">
        <div class="col-md-4">
            <div class="card shadow-sm bg-white">
            <div class="card-body text-center">
                <h5>Total Pengguna</h5>
                <p class="display-6 fw-bold mb-0"><?php echo $totalUsers; ?></p>
            </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card shadow-sm bg-white">
            <div class="card-body text-center">
                <h5>Jumlah Penjualan</h5>
                <p class="display-6 fw-bold mb-0"><?php echo $totalSales; ?></p>
            </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card shadow-sm bg-white">
            <div class="card-body text-center">
                <h5>Total Penghasilan</h5>
                <p class="display-6 fw-bold mb-0 text-success">Rp <?php echo number_format($totalIncome, 0, ',', '.'); ?></p>
            </div>
            </div>
        </div>
        </div>

        <!-- Buku Terlaris -->
        <h4 class="mb-3">Buku Terlaris Bulan Ini</h4>
        <div class="table-responsive">
        <table class="table table-striped table-bordered">
            <thead class="table-dark">
            <tr>
                <th scope="col">No</th>
                <th scope="col">Judul Buku</th>
                <th scope="col">Jumlah Terjual</th>
            </tr>
            </thead>
            <tbody>
            <?php
            if (mysqli_num_rows($resultBestSellers) > 0) {
                $no = 1;
                while($row = mysqli_fetch_assoc($resultBestSellers)) {
                    echo "<tr><td>".$no++."</td><td>".htmlspecialchars($row['nama_buku'])."</td><td>".$row['total_terjual']."</td></tr>";
                }
            } else {
                echo "<tr><td colspan='3' class='text-center'>Tidak ada penjualan bulan ini.</td></tr>";
            }
            ?>
            </tbody>
        </table>
        </div>
    </div>
    </div>
     </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    </body>
    </html>
