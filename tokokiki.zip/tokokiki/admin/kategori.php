<?php
session_start();
include('../config/koneksi.php');

// Cek apakah user sudah login dan memiliki role admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Hapus kategori
if (isset($_GET['hapus'])) {
    $id_kategori = $_GET['hapus'];
    $hapusQuery = "DELETE FROM kategori WHERE id_kategori = '$id_kategori'";
    if (mysqli_query($conn, $hapusQuery)) {
        header("Location: kategori.php");
        exit();
    } else {
        echo "<script>alert('Terjadi kesalahan saat menghapus kategori.');</script>";
    }
}

// Proses update kategori
if (isset($_POST['update_kategori'])) {
    $id_kategori = $_POST['id_kategori'];
    $nama_kategori = $_POST['nama_kategori'];

    $updateQuery = "UPDATE kategori SET nama_kategori = '$nama_kategori' WHERE id_kategori = '$id_kategori'";
    if (mysqli_query($conn, $updateQuery)) {
        header("Location: kategori.php");
        exit();
    } else {
        echo "<script>alert('Gagal memperbarui kategori.');</script>";
    }
}

// Ambil data kategori
$query = "SELECT * FROM kategori";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Daftar Kategori</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php include 'include/sidebar.php'; ?>
<div class="w-100">
<?php include 'include/header.php'; ?>

<div class="container mt-4">
  <h2 class="mb-4">Daftar Kategori</h2>

  <div class="mb-3">
    <a href="tambah_kategori.php" class="btn btn-primary">Tambah Kategori Baru</a>
  </div>

  <div class="table-responsive">
    <table class="table table-bordered table-striped">
      <thead class="table-dark">
        <tr>
          <th>#</th>
          <th>Nama Kategori</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php
        if (mysqli_num_rows($result) > 0) {
            $no = 1;
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>".$no++."</td>";

                // Jika sedang edit kategori
                if (isset($_GET['edit']) && $_GET['edit'] == $row['id_kategori']) {
                    echo "<form method='POST'>";
                    echo "<td>
                            <input type='text' name='nama_kategori' value='".htmlspecialchars($row['nama_kategori'])."' class='form-control' required>
                            <input type='hidden' name='id_kategori' value='".$row['id_kategori']."'>
                          </td>";
                    echo "<td>
                            <button type='submit' name='update_kategori' class='btn btn-success btn-sm'>Simpan</button>
                            <a href='kategori.php' class='btn btn-secondary btn-sm'>Batal</a>
                          </td>";
                    echo "</form>";
                } else {
                    echo "<td>".$row['nama_kategori']."</td>";
                    echo "<td>
                            <a href='kategori.php?edit=".$row['id_kategori']."' class='btn btn-warning btn-sm'>Edit</a>
                            <a href='kategori.php?hapus=".$row['id_kategori']."' onclick='return confirm(\"Yakin ingin menghapus kategori?\")' class='btn btn-danger btn-sm'>Hapus</a>
                          </td>";
                }

                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='3' class='text-center'>Tidak ada kategori.</td></tr>";
        }
        ?>
      </tbody>
    </table>
  </div>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
