<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

include '../config/koneksi.php';

$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : '';
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : '';
$whereClause = '';

if ($start_date && $end_date) {
    $whereClause = "WHERE tanggal BETWEEN '$start_date' AND '$end_date'";
}

$query = "SELECT * FROM penjualan $whereClause ORDER BY tanggal DESC";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Laporan Penjualan</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
    body {
        margin: 0;
        font-family: 'Segoe UI', sans-serif;
        display: flex;
    }
    .sidebar {
        width: 250px;
        background-color: #F8B55F;
        padding: 20px;
        height: 100vh;
    }
    .sidebar h2 {
        color: #fff;
        margin-bottom: 20px;
    }
    .sidebar a {
        display: block;
        color: #fff;
        text-decoration: none;
        padding: 10px;
        margin-bottom: 10px;
        border-radius: 5px;
    }
    .sidebar a:hover,
    .sidebar a.active {
        background-color: #eaa63c;
    }
    .main-content {
        flex: 1;
        padding: 30px;
        background-color: #f9f9f9;
    }
    h1 {
        margin-bottom: 20px;
    }
    .filter-form {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 15px;
        margin-bottom: 20px;
        background: #fff;
        padding: 15px;
        border-radius: 8px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    }
    .filter-form input[type="date"],
    .filter-form select {
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 6px;
        font-size: 14px;
    }
    .filter-form button {
        padding: 10px 15px;
        background-color: #F8B55F;
        border: none;
        border-radius: 6px;
        color: #fff;
        cursor: pointer;
        font-weight: bold;
    }
    .filter-form button:hover {
        background-color: #eaa63c;
    }
    table {
        width: 100%;
        border-collapse: collapse;
        background: #fff;
        box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    }
    th, td {
        border: 1px solid #ddd;
        padding: 10px;
        text-align: left;
    }
    th {
        background-color: #F8B55F;
        color: #fff;
    }
    tr:hover {
        background-color: #f1f1f1;
    }
    .summary {
        margin-top: 15px;
        font-weight: bold;
    }
</style>

</head>
<body>
<div class="sidebar">
    <h2>Admin Menu</h2>
    <a href="dashboard.php">Dashboard</a>
    <div class="dropdown">
        <a href="#" class="dropdown-btn">Kelola Produk</a>
        <div class="dropdown-content">
            <a href="buku_list.php">Daftar Buku</a>
            <a href="kategori.php">Daftar Kategori</a>
        </div>
    </div>
    <a href="laporan_penjualan.php" class="active">Laporan Penjualan</a>
    <a href="users.php">Daftar User</a>
    <a href="../logout.php">Logout</a>
</div>

<div class="main-content">
    <h1>Laporan Penjualan</h1>

    <form method="GET" class="filter-form">
        <label>Dari:</label>
        <input type="date" name="start_date" value="<?= htmlspecialchars($start_date) ?>">
        <label>Sampai:</label>
        <input type="date" name="end_date" value="<?= htmlspecialchars($end_date) ?>">
        <button type="submit">Tampilkan</button>
    </form>

    <table>
        <thead>
        <tr>
            <th>No</th>
            <th>Tanggal</th>
            <th>Nama Buku</th>
            <th>Jumlah</th>
            <th>Total</th>
        </tr>
        </thead>
        <tbody>
        <?php 
        $no = 1;
        $total_semua = 0;
        while($row = mysqli_fetch_assoc($result)): 
            $total_semua += $row['total'];
        ?>
        <tr>
            <td><?= $no++ ?></td>
            <td><?= $row['tanggal'] ?></td>
            <td><?= htmlspecialchars($row['nama_buku']) ?></td>
            <td><?= $row['jumlah'] ?></td>
            <td>Rp<?= number_format($row['total']) ?></td>
        </tr>
        <?php endwhile; ?>
        </tbody>
    </table>

    <div class="export-button">
        <strong>Total Penjualan: Rp<?= number_format($total_semua) ?></strong>
    </div>
</div>
</body>
</html>
