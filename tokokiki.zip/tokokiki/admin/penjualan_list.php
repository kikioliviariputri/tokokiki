<?php
session_start();
include('../config/koneksi.php');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

$query = "SELECT 
            penjualan.id_penjualan, 
            users.username, 
            produk.nama_buku, 
            penjualan.jumlah_terjual, 
            penjualan.total_harga, 
            penjualan.tanggal_penjualan,
            penjualan.status_pembayaran,
            penjualan.status_pengiriman
          FROM penjualan 
          JOIN users ON penjualan.user_id = users.user_id 
          JOIN produk ON penjualan.id_buku = produk.id_buku 
          ORDER BY penjualan.tanggal_penjualan DESC";

$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>List Penjualan</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body>
  <?php include 'include/sidebar.php'; ?>
  <?php include 'include/header.php'; ?>

  <div class="container mt-4">
    <h2 class="mb-4"><i class="fas fa-box me-2"></i>Daftar Penjualan</h2>

    <div class="table-responsive">
      <table class="table table-bordered table-striped">
        <thead class="table-dark">
          <tr>
            <th>#</th>
            <th>User</th>
            <th>Nama Buku</th>
            <th>Jumlah Terjual</th>
            <th>Total Harga</th>
            <th>Tanggal</th>
            <th>Status Pembayaran</th>
            <th>Status Pengiriman</th>
          </tr>
        </thead>
        <tbody>
          <?php if (mysqli_num_rows($result) > 0): ?>
            <?php $no = 1; ?>
            <?php while ($row = mysqli_fetch_assoc($result)): ?>
              <tr>
                <td><?= $no++ ?></td>
                <td><?= htmlspecialchars($row['username']) ?></td>
                <td><?= htmlspecialchars($row['nama_buku']) ?></td>
                <td><?= $row['jumlah_terjual'] ?></td>
                <td>Rp <?= number_format($row['total_harga'], 0, ',', '.') ?></td>
                <td><?= $row['tanggal_penjualan'] ?></td>

                <!-- Form status pembayaran -->
                <td>
                  <form method="post" action="update_pembayaran.php" class="d-flex">
                    <input type="hidden" name="id_penjualan" value="<?= $row['id_penjualan'] ?>">
                    <select name="status_pembayaran" class="form-select form-select-sm me-2">
                      <option value="belum dibayar" <?= $row['status_pembayaran'] === 'belum dibayar' ? 'selected' : '' ?>>Belum Dibayar</option>
                      <option value="sudah dibayar" <?= $row['status_pembayaran'] === 'sudah dibayar' ? 'selected' : '' ?>>Sudah Dibayar</option>
                    </select>
                    <button type="submit" class="btn btn-sm btn-primary text-white">
                      <i class="fas fa-check fa-sm"></i>
                    </button>
                  </form>
                </td>

                <!-- Form status pengiriman -->
                <td>
                  <form method="post" action="update_pengiriman.php" class="d-flex">
                    <input type="hidden" name="id_penjualan" value="<?= $row['id_penjualan'] ?>">
                    <select name="status_pengiriman" class="form-select form-select-sm me-2">
                      <option value="belum dikirim" <?= $row['status_pengiriman'] === 'belum dikirim' ? 'selected' : '' ?>>Belum Dikirim</option>
                      <option value="dikirim" <?= $row['status_pengiriman'] === 'dikirim' ? 'selected' : '' ?>>Dikirim</option>
                      <option value="sampai" <?= $row['status_pengiriman'] === 'sampai' ? 'selected' : '' ?>>Sampai</option>
                    </select>
                    <button type="submit" class="btn btn-sm btn-success text-white">
                      <i class="fas fa-check fa-sm"></i>
                    </button>
                  </form>
                </td>
              </tr>
            <?php endwhile; ?>
          <?php else: ?>
            <tr>
              <td colspan="8" class="text-center">Belum ada data penjualan.</td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
