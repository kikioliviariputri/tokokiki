<?php
session_start();
include('../config/koneksi.php');

// Cek apakah user sudah login dan memiliki role admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Menghapus produk
if (isset($_GET['hapus'])) {
    $id_buku = $_GET['hapus'];
    
    // Query untuk menghapus produk
    $hapusQuery = "DELETE FROM produk WHERE id_buku = '$id_buku'";
    
    if (mysqli_query($conn, $hapusQuery)) {
        // Menampilkan peringatan sukses
        echo "<script>
                alert('Produk berhasil dihapus!');
                window.location.href = 'produk.php';
              </script>";
    } else {
        // Menampilkan peringatan gagal
        echo "<script>
                alert('Terjadi kesalahan saat menghapus produk.');
                window.location.href = 'produk.php';
              </script>";
    }
}

// Query untuk mengambil semua produk
$query = "SELECT * FROM produk";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Daftar Produk</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
  <?php include 'include/sidebar.php'; ?>
  <div class="w-100">
    <?php include 'include/header.php'; ?>
<div class="container">
    <div class="content">
      <h2 class="mb-4">Daftar Produk</h2>

      <div class="mb-3">
        <a href="tambah_produk.php" class="btn btn-primary">Tambah Produk Baru</a>
      </div>

      <div class="table-responsive">
        <table class="table table-bordered table-striped">
          <thead class="table-dark">
            <tr>
              <th>#</th>
              <th>Nama Buku</th>
              <th>Penerbit</th>
              <th>Harga</th>
              <th>Stok</th>
              <th>Kategori</th>
              <th>Gambar</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php
            if (mysqli_num_rows($result) > 0) {
                $no = 1;
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>".$no++."</td>";
                    echo "<td>".$row['nama_buku']."</td>";
                    echo "<td>".$row['penerbit']."</td>";
                    echo "<td>Rp ".number_format($row['harga'], 0, ',', '.')."</td>";
                    echo "<td>".$row['stok']."</td>";

                    // Menampilkan nama kategori berdasarkan kategori_id
                    $kategoriQuery = "SELECT nama_kategori FROM kategori WHERE id_kategori = ".$row['kategori_id'];
                    $kategoriResult = mysqli_query($conn, $kategoriQuery);
                    $kategori = mysqli_fetch_assoc($kategoriResult);
                    echo "<td>".$kategori['nama_kategori']."</td>";
           echo "<td><img src='../img/uploads/" . $row['gambar'] . "' width='50'></td>";

                    echo "<td>
                            <a href='edit_produk.php?id_buku=".$row['id_buku']."' class='btn btn-warning btn-sm'>Edit</a>
                            <a href='produk.php?hapus=".$row['id_buku']."' onclick='return confirmDelete()' class='btn btn-danger btn-sm'>Hapus</a>
                          </td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='8' class='text-center'>Tidak ada produk.</td></tr>";
            }
            ?>
            
          </tbody>
        </table>
      </div>
    </div>
  </div>
        </div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

  <script>
    function confirmDelete() {
        return confirm('Yakin ingin menghapus produk ini?'); // Konfirmasi hapus
    }
  </script>
</body>
</html>
