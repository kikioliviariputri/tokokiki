<?php
session_start();
include('../config/koneksi.php');

// Cek apakah user sudah login dan memiliki role admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Proses tambah kategori
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama_kategori = mysqli_real_escape_string($conn, $_POST['nama_kategori']);

    // Query untuk insert kategori baru
    $query = "INSERT INTO kategori (nama_kategori) VALUES ('$nama_kategori')";
    
    if (mysqli_query($conn, $query)) {
        echo "<script>alert('Kategori berhasil ditambahkan!');</script>";
        header("Location: kategori.php"); // Redirect ke halaman daftar kategori
    } else {
        echo "<script>alert('Terjadi kesalahan saat menambahkan kategori.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Tambah Kategori</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
  <?php include 'include/sidebar.php'; ?>
  <div class="w-100">
    <?php include 'include/header.php'; ?>
<div class="container">
    <div class="content">
      <h2 class="mb-4">Tambah Kategori Baru</h2>

      <form action="tambah_kategori.php" method="POST">
        <div class="mb-3">
          <label for="nama_kategori" class="form-label">Nama Kategori</label>
          <input type="text" class="form-control" id="nama_kategori" name="nama_kategori" required>
        </div>
        <button type="submit" class="btn btn-primary">Tambah Kategori</button>
      </form>
    </div>
  </div></div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
