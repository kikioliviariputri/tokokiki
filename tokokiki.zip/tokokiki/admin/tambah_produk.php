<?php
session_start();
include('../config/koneksi.php');

// Cek apakah user sudah login dan memiliki role admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil data form
    $nama_buku = mysqli_real_escape_string($conn, $_POST['nama_buku']);
    $penerbit = mysqli_real_escape_string($conn, $_POST['penerbit']);
    $harga = mysqli_real_escape_string($conn, $_POST['harga']);
    $stok = mysqli_real_escape_string($conn, $_POST['stok']);
    $kategori_id = mysqli_real_escape_string($conn, $_POST['kategori_id']);
    
    // Validasi gambar
    $gambar = '';
    if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] == 0) {
        $gambar_name = $_FILES['gambar']['name'];
        $gambar_tmp_name = $_FILES['gambar']['tmp_name'];
        $gambar_ext = pathinfo($gambar_name, PATHINFO_EXTENSION);
        $gambar_new_name = 'produk_' . time() . '.' . $gambar_ext;

        // Direktori upload
        $upload_dir = '../img/uploads/';
        $upload_file = $upload_dir . $gambar_new_name;

        // Cek ekstensi gambar
        $allowed_ext = ['jpg', 'jpeg', 'png', 'gif'];
        if (in_array(strtolower($gambar_ext), $allowed_ext)) {
            move_uploaded_file($gambar_tmp_name, $upload_file);
            $gambar = $gambar_new_name;
        } else {
            echo "<script>alert('Format gambar tidak valid!');</script>";
        }
    }

    // Query untuk memasukkan produk ke database
    $query = "INSERT INTO produk (nama_buku, penerbit, harga, stok, kategori_id, gambar, created_at) 
              VALUES ('$nama_buku', '$penerbit', '$harga', '$stok', '$kategori_id', '$gambar', NOW())";
    
    if (mysqli_query($conn, $query)) {
        echo "<script>alert('Produk berhasil ditambahkan!');</script>";
        header("Location: produk.php"); // Redirect ke halaman daftar produk
    } else {
        echo "<script>alert('Terjadi kesalahan saat menambahkan produk.');</script>";
    }
}

// Ambil daftar kategori
$kategori_query = mysqli_query($conn, "SELECT * FROM kategori");
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Tambah Produk</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
  
  <?php include 'include/sidebar.php'; ?>
  <?php include 'include/header.php'; ?>
  <div class="w-100">
<div class="container">
    <div class="content">
      <h2 class="mb-4">Tambah Produk Baru</h2>

      <form action="tambah_produk.php" method="POST" enctype="multipart/form-data">
        <div class="mb-3">
          <label for="nama_buku" class="form-label">Nama Buku</label>
          <input type="text" class="form-control" id="nama_buku" name="nama_buku" required>
        </div>
        <div class="mb-3">
          <label for="penerbit" class="form-label">Penerbit</label>
          <input type="text" class="form-control" id="penerbit" name="penerbit" required>
        </div>
        <div class="mb-3">
          <label for="harga" class="form-label">Harga</label>
          <input type="number" class="form-control" id="harga" name="harga" required>
        </div>
        <div class="mb-3">
          <label for="stok" class="form-label">Stok</label>
          <input type="number" class="form-control" id="stok" name="stok" required>
        </div>
        <div class="mb-3">
          <label for="kategori_id" class="form-label">Kategori</label>
          <select class="form-control" id="kategori_id" name="kategori_id" required>
            <option value="">Pilih Kategori</option>
            <?php while ($kategori = mysqli_fetch_assoc($kategori_query)) { ?>
              <option value="<?php echo $kategori['id_kategori']; ?>"><?php echo $kategori['nama_kategori']; ?></option>
            <?php } ?>
          </select>
        </div>
        <div class="mb-3">
          <label for="gambar" class="form-label">Gambar Produk</label>
          <input type="file" class="form-control" id="gambar" name="gambar" accept="image/*" required>
        </div>
        <button type="submit" class="btn btn-primary">Tambah Produk</button>
      </form>
    </div>
  </div>
</div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
