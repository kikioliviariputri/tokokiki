<?php
session_start();
include('../config/koneksi.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_POST['id_penjualan']);
    $status = $_POST['status_pengiriman'];

    $valid = ['belum dikirim', 'dikirim', 'sampai'];
    if (!in_array($status, $valid)) exit('Status tidak valid');

    $stmt = $conn->prepare("UPDATE penjualan SET status_pengiriman = ? WHERE id_penjualan = ?");
    $stmt->bind_param("si", $status, $id);
    $stmt->execute();

    header("Location: penjualan_list.php");
}
