<?php
session_start();
include('../config/koneksi.php');

// Cek apakah user sudah login dan memiliki role admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Query untuk mengambil semua data user
$query = "SELECT * FROM users";
$result = mysqli_query($conn, $query);

// Hapus user
if (isset($_GET['hapus'])) {
    $id_user = $_GET['hapus'];
    $hapusQuery = "DELETE FROM users WHERE user_id = '$id_user'";
    if (mysqli_query($conn, $hapusQuery)) {
        echo "<script>alert('User berhasil dihapus!');</script>";
        header("Location: users.php");
    } else {
        echo "<script>alert('Terjadi kesalahan saat menghapus user.');</script>";
    }
}

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Manajemen User</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <?php include 'include/sidebar.php'; ?>
    <div class="w-100">
        <?php include 'include/header.php'; ?>
        <div class="container mt-4">
            <h2>Daftar User</h2>
            

            <div class="table-responsive">
                <table class="table table-bordered table-striped">
                    <thead class="table-dark">
                        <tr>
                            <th>#</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if (mysqli_num_rows($result) > 0) {
                            $no = 1;
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<tr>";
                                echo "<td>".$no++."</td>";
                                echo "<td>".$row['username']."</td>";
                                echo "<td>".$row['email']."</td>";
                                echo "<td>".$row['role']."</td>";
                                echo "<td>
                                        <a href='edit_user.php?user_id=".$row['user_id']."' class='btn btn-warning btn-sm'>Edit</a>
                                        <a href='users.php?hapus=".$row['user_id']."' onclick='return confirm(\"Yakin ingin menghapus user?\")' class='btn btn-danger btn-sm'>Hapus</a>
                                      </td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='5' class='text-center'>Tidak ada user.</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
