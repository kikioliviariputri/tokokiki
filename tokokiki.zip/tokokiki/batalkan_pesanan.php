<?php
session_start();
include('config/koneksi.php');

if (!isset($_SESSION['user_id']) || !isset($_GET['id'])) {
    header("Location: pesanan_saya.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$id_checkout = (int)$_GET['id'];

// Validasi: hanya bisa batalkan jika belum dibayar
$cek = mysqli_query($conn, "SELECT * FROM checkout WHERE id_checkout = $id_checkout AND user_id = $user_id AND status_pembayaran = 'belum_dibayar'");
if (mysqli_num_rows($cek) > 0) {
    mysqli_query($conn, "UPDATE checkout SET status_pembayaran = 'batal', status_pengiriman = 'batal' WHERE id_checkout = $id_checkout");
    $_SESSION['notif'] = "✅ Pesanan berhasil dibatalkan.";
} else {
    $_SESSION['notif'] = "❌ Tidak bisa membatalkan pesanan ini.";
}
header("Location: pesanan_saya.php");
exit();
?>
