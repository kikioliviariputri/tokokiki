<?php
session_start();
include('config/koneksi.php');

// Cek jika user belum login
if (!isset($_SESSION['user_id'])) {
    $_SESSION['notif'] = "Silakan login terlebih dahulu.";
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
if (isset($_GET['hapus'])) {
    $id_keranjang = intval($_GET['hapus']);
    mysqli_query($conn, "DELETE FROM keranjang WHERE id_keranjang = $id_keranjang AND user_id = $user_id");
    $_SESSION['notif'] = "Item berhasil dihapus dari keranjang.";
    header("Location: cart.php");
    exit();
}

// Jika aksi menambah produk ke keranjang
if (isset($_GET['aksi']) && $_GET['aksi'] == 'tambah' && isset($_GET['id'])) {
    $id_buku = $_GET['id'];
    
    // Periksa apakah buku sudah ada di keranjang
    $check_cart = mysqli_query($conn, "SELECT * FROM keranjang WHERE user_id = $user_id AND id_buku = $id_buku");
    
    if (mysqli_num_rows($check_cart) > 0) {
        // Jika sudah ada, update jumlahnya
        mysqli_query($conn, "UPDATE keranjang SET jumlah = jumlah + 1 WHERE user_id = $user_id AND id_buku = $id_buku");
    } else {
        // Jika belum ada, insert ke keranjang
        mysqli_query($conn, "INSERT INTO keranjang (user_id, id_buku, jumlah) VALUES ($user_id, $id_buku, 1)");
    }
    
    // Redirect kembali ke halaman katalog setelah menambahkan produk ke keranjang
    header("Location: index.php?add=success");
    exit();
}

// Ambil data keranjang untuk ditampilkan
$cart_query = mysqli_query($conn, "
    SELECT k.id_keranjang, p.nama_buku, p.harga, p.gambar, k.jumlah, (p.harga * k.jumlah) AS total
    FROM keranjang k
    JOIN produk p ON k.id_buku = p.id_buku
    WHERE k.user_id = $user_id
");

$total_all = 0;
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Keranjang Belanja</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container my-5">
    <h2 class="mb-4">🛒 Keranjang Belanja Anda</h2>
    
    <?php if (isset($_SESSION['notif'])): ?>
        <div class="alert alert-info">
            <?= $_SESSION['notif']; ?>
            <?php unset($_SESSION['notif']); ?>
        </div>
    <?php endif; ?>
    
    <div class="table-responsive">
        <table class="table table-bordered text-center">
            <thead class="table-dark">
                <tr>
                    <th>Gambar</th>
                    <th>Judul Buku</th>
                    <th>Jumlah</th>
                    <th>Harga</th>
                    <th>Total</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (mysqli_num_rows($cart_query) > 0): ?>
                    <?php while ($row = mysqli_fetch_assoc($cart_query)): ?>
                        <?php $total_all += $row['total']; ?>
                        <tr>
                            <td><img src="img/uploads/<?= htmlspecialchars($row['gambar']); ?>" width="50"></td>
                            <td><?= htmlspecialchars($row['nama_buku']); ?></td>
                            <td><?= $row['jumlah']; ?></td>
                            <td>Rp <?= number_format($row['harga'], 0, ',', '.'); ?></td>
                            <td>Rp <?= number_format($row['total'], 0, ',', '.'); ?></td>
                            <td>
                                <a href="delete_cart.php?hapus=<?= $row['id_keranjang']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Hapus item ini?')">
                                    Hapus
                                </a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="6">Keranjang Anda kosong.</td></tr>
                <?php endif; ?>
            </tbody>
            <tfoot>
                <tr>
                    <th colspan="4" class="text-end">Total Belanja:</th>
                    <th>Rp <?= number_format($total_all, 0, ',', '.'); ?></th>
                    <th></th>
                </tr>
            </tfoot>
        </table>
    </div>
    
    <div class="d-flex justify-content-between">
        <a href="index.php" class="btn btn-secondary">Belanja Lagi</a>
        <?php if ($total_all > 0): ?>
            <a href="checkout.php" class="btn btn-success">Checkout</a>
            <?php endif; ?>
        </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
