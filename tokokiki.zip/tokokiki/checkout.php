<?php
session_start();
include('config/koneksi.php');

if (!isset($_SESSION['user_id'])) {
    $_SESSION['notif'] = "Silakan login terlebih dahulu untuk melanjutkan checkout.";
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$total_harga = 0;
$produk = [];

$query = mysqli_query($conn, "
    SELECT p.id_buku, p.nama_buku, p.harga, k.jumlah, (p.harga * k.jumlah) AS total
    FROM keranjang k
    JOIN produk p ON k.id_buku = p.id_buku
    WHERE k.user_id = $user_id
");

while ($row = mysqli_fetch_assoc($query)) {
    $total_harga += $row['total'];
    $produk[] = $row;
}

if (empty($produk)) {
    header("Location: cart.php");
    exit();
}

$query_user = mysqli_query($conn, "SELECT fullname FROM users WHERE user_id = $user_id");
$user_data = mysqli_fetch_assoc($query_user);
$fullname = $user_data['fullname'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $metode_pembayaran = $_POST['metode_pembayaran'];

    $alamat_pengiriman = mysqli_real_escape_string($conn, $_POST['alamat_pengiriman']);
    $nomor_telepon = mysqli_real_escape_string($conn, $_POST['nomor_telepon']);

    $query_checkout = "
        INSERT INTO checkout (user_id, total_harga, metode_pembayaran, alamat_pengiriman, nomor_telepon, status_pembayaran)
        VALUES ($user_id, $total_harga, '$metode_pembayaran', '$alamat_pengiriman', '$nomor_telepon', 'belum_dibayar')
    ";
    
    if (mysqli_query($conn, $query_checkout)) {
        $checkout_id = mysqli_insert_id($conn);

        foreach ($produk as $item) {
            $query_penjualan = "
                INSERT INTO penjualan (user_id, id_buku, jumlah_terjual, total_harga, tanggal_penjualan)
                VALUES ($user_id, {$item['id_buku']}, {$item['jumlah']}, {$item['total']}, NOW())
            ";
            mysqli_query($conn, $query_penjualan);
        }

        mysqli_query($conn, "DELETE FROM keranjang WHERE user_id = $user_id");

        $_SESSION['checkout_id'] = $checkout_id;
        $_SESSION['notif'] = "Checkout berhasil! Silakan lanjutkan pembayaran.";
        header("Location: pembayaran.php");
        exit();
    } else {
        $_SESSION['notif'] = "Terjadi kesalahan saat melakukan checkout. Silakan coba lagi.";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Checkout - Toko Kiki</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .checkout-box {
            background: white;
            padding: 30px;
            border-radius: 16px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        .form-check-label {
            font-weight: 500;
        }
        .rekening-box {
            margin-top: 15px;
            padding: 15px;
            border-radius: 10px;
            background-color: #e9f7ef;
        }
    </style>
</head>
<body>
<div class="container my-5">
    <div class="checkout-box mx-auto" style="max-width: 700px;">
        <h3 class="mb-4">🧾 Checkout</h3>

        <?php if (isset($_SESSION['notif'])): ?>
            <div class="alert alert-info alert-dismissible fade show" role="alert">
                <?= $_SESSION['notif']; unset($_SESSION['notif']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <p class="mb-4">Halo <strong><?= htmlspecialchars($fullname); ?></strong>, silakan lengkapi detail checkout kamu.</p>

        <form action="checkout.php" method="POST">
            <!-- Alamat -->
            <div class="mb-3">
                <label for="alamat_pengiriman" class="form-label">Alamat Pengiriman</label>
                <textarea name="alamat_pengiriman" id="alamat_pengiriman" rows="3" class="form-control" required></textarea>
            </div>

            <!-- Nomor Telepon -->
            <div class="mb-3">
                <label for="nomor_telepon" class="form-label">Nomor Telepon</label>
                <input type="text" name="nomor_telepon" id="nomor_telepon" class="form-control" required>
            </div>

            <!-- Metode Pembayaran -->
            <h5 class="mb-3">Pilih Metode Pembayaran</h5>
            <div class="mb-3">
                <?php
                $metodes = ['BRI', 'BCA', 'BSI', 'OVO', 'Gopay', 'Dana'];
                foreach ($metodes as $metode): ?>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="metode_pembayaran" id="<?= strtolower($metode) ?>" value="<?= $metode ?>" onchange="tampilkanRekening(this.value)" required>
                        <label class="form-check-label" for="<?= strtolower($metode) ?>">
                            <?= $metode === 'BRI' || $metode === 'BCA' || $metode === 'BSI' ? "Transfer Bank $metode" : $metode ?>
                        </label>
                    </div>
                <?php endforeach; ?>
            </div>

            <div id="info-rekening" class="rekening-box d-none">
                <strong>Transfer ke:</strong><br>
                Bank/Metode: <span id="nama-bank"></span><br>
                Nomor: <span id="nomor-rekening"></span><br>
                Atas Nama: <strong>PT Toko Kiki Bersama</strong>
            </div>

            <h5 class="mt-4">Total: <span class="text-success">Rp <?= number_format($total_harga, 0, ',', '.'); ?></span></h5>

            <div class="d-flex justify-content-between mt-4">
                <a href="cart.php" class="btn btn-outline-secondary">← Kembali</a>
                <button type="submit" class="btn btn-success">💳 Proses Pembayaran</button>
            </div>
        </form>
    </div>
</div>

<script>
function tampilkanRekening(metode) {
    const infoBox = document.getElementById('info-rekening');
    const namaBank = document.getElementById('nama-bank');
    const nomorRekening = document.getElementById('nomor-rekening');

    let data = {
        'BRI': ['BRI', '1234567890'],
        'BCA': ['BCA', '9876543210'],
        'BSI': ['BSI', '5678901234'],
        'OVO': ['OVO', '081234567890'],
        'Gopay': ['Gopay', '081987654321'],
        'Dana': ['Dana', '085612345678']
    };

    if (data[metode]) {
        namaBank.innerText = data[metode][0];
        nomorRekening.innerText = data[metode][1];
        infoBox.classList.remove('d-none');
    }
}
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
