<?php
session_start();
include('config/koneksi.php');

// Jika pengguna belum login, arahkan ke halaman login
if (!isset($_SESSION['user_id'])) {
    $_SESSION['notif'] = "Silakan login terlebih dahulu untuk mengakses keranjang.";
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
// Pastikan id_keranjang valid
if (isset($_GET['hapus']) && is_numeric($_GET['hapus'])) {
    $id_keranjang = intval($_GET['hapus']);

    // Hapus item dari keranjang
    $query = "DELETE FROM keranjang WHERE id_keranjang = $id_keranjang AND user_id = $user_id";
    if (mysqli_query($conn, $query)) {
        $_SESSION['notif'] = "Item berhasil dihapus dari keranjang.";
    } else {
        $_SESSION['notif'] = "Terjadi kesalahan saat menghapus item.";
    }
} else {
    $_SESSION['notif'] = "Item tidak ditemukan.";
}

// Redirect ke halaman cart.php setelah menghapus item
header("Location: cart.php");
exit();
