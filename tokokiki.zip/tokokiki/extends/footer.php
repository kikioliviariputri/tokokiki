    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js" integrity="sha384-j1CDi7MgGQ12Z7Qab0qlWQ/Qqz24Gc6BM0thvEMVjHnfYGF0rmFCozFSxQBxwHKO" crossorigin="anonymous"></script>
  </body>
</html>
<footer class="bg-dark text-white py-4">
  <div class="container">
    <div class="row">
      <!-- Kolom 1: Tentang Toko -->
      <div class="col-md-4">
        <h5>Tentang Kami</h5>
        <p>TokoKiki adalah toko buku online yang menyediakan berbagai pilihan buku dengan harga terjangkau. Kami berkomitmen untuk mempermudah kamu dalam menemukan buku yang kamu inginkan.</p>
      </div>

      <!-- Kolom 2: Menu Cepat -->
      <div class="col-md-4">
        <h5>Menu Cepat</h5>
        <ul class="list-unstyled">
          <li><a href="#beranda" class="text-white text-decoration-none">Beranda</a></li>
          <li><a href="#promo" class="text-white text-decoration-none">Promo</a></li>
          <li><a href="#catalog" class="text-white text-decoration-none">Katalog</a></li>
          <li><a href="#review" class="text-white text-decoration-none">Review</a></li>
          <li><a href="#profil" class="text-white text-decoration-none">Profil Toko</a></li>
        </ul>
      </div>

      <!-- Kolom 3: Sosial Media -->
      <div class="col-md-4">
        <h5>Ikuti Kami</h5>
        <ul class="list-unstyled d-flex">
          <li><a href="https://www.instagram.com" class="text-white me-3"><i class="bi bi-instagram"></i></a></li>
          <li><a href="https://www.facebook.com" class="text-white me-3"><i class="bi bi-facebook"></i></a></li>
          <li><a href="https://www.twitter.com" class="text-white me-3"><i class="bi bi-twitter"></i></a></li>
          <li><a href="https://www.linkedin.com" class="text-white me-3"><i class="bi bi-linkedin"></i></a></li>
          <li><a href="https://www.youtube.com" class="text-white me-3"><i class="bi bi-youtube"></i></a></li>
          <li><a href="https://www.pinterest.com" class="text-white"><i class="bi bi-pinterest"></i></a></li>
        </ul>
      </div>
    </div>
    <hr class="border-top border-white">
    <div class="text-center">
      <p>&copy; 2025 TokoKiki. All rights reserved.</p>
    </div>
  </div>
</footer>