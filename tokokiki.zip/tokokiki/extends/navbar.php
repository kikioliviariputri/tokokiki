<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include('config/koneksi.php');

// Cek apakah pengguna sudah login
$isLoggedIn = isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);


// Pastikan user sudah login
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];

    // Query untuk menghitung jumlah item dalam keranjang
    $query_cart = "SELECT SUM(jumlah) AS total_items FROM keranjang WHERE user_id = $user_id";
    $result_cart = mysqli_query($conn, $query_cart);
    $cart_data = mysqli_fetch_assoc($result_cart);
    $total_items = $cart_data['total_items'] ? $cart_data['total_items'] : 0;
} else {
    $total_items = 0;
}
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4Q6Gf2aSP4eDXB8Miphtr37CMZZQ5oXLH2yaXMJ2w8e2ZtHTl7GptT4jmndRuHDT" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="styles.css">
  </head>
  <body>
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm sticky-top">
  <div class="container">
    <a class="navbar-brand fw-bold text-primary" href="index.php">
      <i class="bi bi-book-half me-2"></i> TokoKiki
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarEcommerce">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarEcommerce">
      <!-- Search Bar -->
      <form class="d-flex mx-auto w-50">
        <input class="form-control me-2" type="search" placeholder="Cari buku..." aria-label="Search">
        <button class="btn btn-outline-primary" type="submit">
          <i class="bi bi-search"></i>
        </button>
      </form>

      <!-- Menu Navigasi -->
      <ul class="navbar-nav ms-auto align-items-center">
        <li class="nav-item me-3"><a class="nav-link" href="index.php#beranda">Beranda</a></li>
        <li class="nav-item me-3"><a class="nav-link" href="index.php#promo">Promo</a></li>
        <li class="nav-item me-3"><a class="nav-link" href="index.php#katalog">Katalog</a></li>
        <li class="nav-item me-3"><a class="nav-link" href="index.php#review">Review</a></li>
        <li class="nav-item me-3"><a class="nav-link" href="index.php#profil">Profil</a></li>

        <!-- Keranjang -->
        <li class="nav-item">
                    <a class="nav-link position-relative" href="cart.php">
                        <i class="bi bi-cart-fill" style=""></i>
                        <?php if ($total_items > 0 && $total_items <100): ?>
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" style="font-size: 0.8rem; margin-top: 0px;">
                                <?= $total_items ?>
                            </span>
                        <?php endif; ?>
                        <?php if ($total_items > 98): ?>
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" style="font-size: 0.8rem; margin-top: 0px;">
                                99+
                            </span>
                        <?php endif; ?>
                    </a>
                </li>

        <!-- Tombol Login / Logout -->
        <?php if ($isLoggedIn): ?>
          <li class="nav-item ms-3">
            <a href="logout.php" class="btn btn-outline-danger btn-sm">Logout</a>
          </li>
        <?php else: ?>
          <li class="nav-item ms-3">
            <a href="login.php" class="btn btn-outline-primary btn-sm">Login</a>
          </li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>
