<?php
session_status();
include('extends/navbar.php');
include('config/koneksi.php');

$query = "SELECT produk.*, kategori.nama_kategori FROM produk 
          JOIN kategori ON produk.kategori_id = kategori.id_kategori 
          ORDER BY created_at DESC";
$result = mysqli_query($conn, $query);
?>
    <!-- HERO -->
<section class="py-5 bg-light" id="beranda">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-md-6">
        <h1 class="display-5 fw-bold">Temukan Buku Favoritmu di <span class="text-primary">TokoBuku</span></h1>
        <p class="lead mt-3">
          Diskon hingga <strong>50%</strong> untuk buku-buku pilihan! Koleksi lengkap dari fiksi hingga buku pelajaran.
          Belanja mudah, cepat, dan hemat hanya di TokoBuku.
        </p>
        <a href="#katalog" class="btn btn-primary btn-lg mt-3">Belanja Sekarang</a>
      </div>
      <div class="col-md-6 text-center">
        <img src="img/banner.png" alt="Hero Buku" class="img-fluid" style="max-height: 400px;">
      </div>
    </div>
  </div>
</section>

  <section class="py-5 bg-white" id="promo">
  <div class="container">
    <h2 class="text-center mb-4">Promo Spesial</h2>
    <div class="row g-4">
      
      <!-- Promo 1 -->
      <div class="col-md-4">
        <div class="card border-primary h-100 shadow-sm">
          <div class="card-body text-center">
            <h5 class="card-title text-primary">Diskon 50%</h5>
            <p class="card-text">Nikmati potongan harga hingga 50% untuk buku-buku best seller minggu ini. Stok terbatas!</p>
            <a href="#katalog" class="btn btn-outline-primary btn-sm">Lihat Buku</a>
          </div>
        </div>
      </div>

      <!-- Promo 2 -->
      <div class="col-md-4">
        <div class="card border-success h-100 shadow-sm">
          <div class="card-body text-center">
            <h5 class="card-title text-success">Beli 2 Gratis 1</h5>
            <p class="card-text">Beli 2 buku apapun dan dapatkan 1 buku gratis khusus kategori pendidikan dan motivasi!</p>
            <a href="#katalog" class="btn btn-outline-success btn-sm">Lihat Promo</a>
          </div>
        </div>
      </div>

      <!-- Promo 3 -->
      <div class="col-md-4">
        <div class="card border-warning h-100 shadow-sm">
          <div class="card-body text-center">
            <h5 class="card-title text-warning">Flash Sale Hari Ini</h5>
            <p class="card-text">Promo kilat hanya hari ini! Buku pilihan mulai dari Rp 10.000. Cuma sampai jam 23.59!</p>
            <a href="#katalog" class="btn btn-outline-warning btn-sm">Belanja Sekarang</a>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>

     <section>
<div class="container my-5">
  <h2 class="mb-4 fw-bold text-center">📚 Katalog Buku</h2>
  <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4">

<?php while ($row = mysqli_fetch_assoc($result)): ?>
    <div class="col">
        <div class="card h-100 shadow-sm border-0">
            <img src="img/uploads/<?php echo htmlspecialchars($row['gambar']); ?>" 
                 class="card-img-top" 
                 alt="<?php echo htmlspecialchars($row['nama_buku']); ?>" 
                 style="height: 200px; object-fit: cover;">
            <div class="card-body">
                <h5 class="card-title">
                    <a href="detail_produk.php?id=<?php echo $row['id_buku']; ?>" class="text-decoration-none text-dark">
                        <?php echo htmlspecialchars($row['nama_buku']); ?>
                    </a>
                </h5>
                <p class="mb-1">📖 <?php echo htmlspecialchars($row['penerbit']); ?></p>
                <p class="mb-1">📂 <?php echo htmlspecialchars($row['nama_kategori']); ?></p>
                <p class="fw-bold text-success">Rp <?php echo number_format($row['harga'], 0, ',', '.'); ?></p>
            </div>
            <div class="card-footer bg-white border-0 d-flex justify-content-end gap-2">
                <a href="cart.php?aksi=tambah&id=<?= $row['id_buku']; ?>&add=success" class="btn btn-sm btn-outline-secondary" title="Tambah ke Keranjang">
                    <i class="bi bi-cart-plus"></i>
                </a>
                <a href="checkout.php?id=<?php echo $row['id_buku']; ?>" class="btn btn-sm btn-success" title="Beli Sekarang">
                    Beli Sekarang
                </a>
            </div>
        </div>
    </div>
<?php endwhile; ?>


  </div>
</div>
     </section>

     <section class="py-5 bg-light" id="review">
  <div class="container">
    <h2 class="text-center mb-4">Apa Kata Pelanggan Kami?</h2>
    
    <!-- Carousel Review -->
    <div id="carouselReview" class="carousel slide" data-bs-ride="carousel">
      <div class="carousel-inner">
        
        <!-- Review 1 -->
        <div class="carousel-item active">
          <div class="card text-center shadow-sm border-0">
            <div class="card-body">
              <i class="bi bi-quote display-3 text-primary mb-3"></i>
              <p class="card-text">“TokoBuku selalu punya pilihan buku terbaru dengan harga yang terjangkau. Belanja di sini sangat mudah dan cepat!”</p>
              <h5 class="card-title">Siti Aulia</h5>
              <p class="text-muted">Penggemar Novel</p>
            </div>
          </div>
        </div>

        <!-- Review 2 -->
        <div class="carousel-item">
          <div class="card text-center shadow-sm border-0">
            <div class="card-body">
              <i class="bi bi-quote display-3 text-primary mb-3"></i>
              <p class="card-text">“Saya selalu membeli buku pendidikan di TokoBuku, dan pelayanan mereka sangat memuaskan. Buku selalu tiba tepat waktu!”</p>
              <h5 class="card-title">Joko Santoso</h5>
              <p class="text-muted">Guru Sekolah Dasar</p>
            </div>
          </div>
        </div>

        <!-- Review 3 -->
        <div class="carousel-item">
          <div class="card text-center shadow-sm border-0">
            <div class="card-body">
              <i class="bi bi-quote display-3 text-primary mb-3"></i>
              <p class="card-text">“Belanja buku di TokoBuku sangat mudah. Saya bisa menemukan berbagai pilihan buku motivasi dengan harga yang sangat bersaing!”</p>
              <h5 class="card-title">Rina Wulandari</h5>
              <p class="text-muted">Entrepreneur</p>
            </div>
          </div>
        </div>

      </div>
      <!-- Controls -->
      <button class="carousel-control-prev" type="button" data-bs-target="#carouselReview" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
      </button>
      <button class="carousel-control-next" type="button" data-bs-target="#carouselReview" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
      </button>
    </div>
    
  </div>
</section>

<section id="profil" class="profil-toko py-5">
  <div class="container">
    <h2 class="text-center mb-4">Profil TokoKiki</h2>
    <p class="text-center mb-5">TokoKiki adalah toko buku online terpercaya yang menyediakan berbagai pilihan buku dengan kualitas terbaik. Kami tidak hanya menjual buku, tetapi juga mengutamakan pengalaman belanja yang menyenangkan bagi setiap pelanggan.</p>
    <div class="text-center mt-4">
      <p>Temukan lebih banyak buku dan promo menarik hanya di <strong>TokoKiki</strong>! Belanja mudah, buku berkualitas, harga terjangkau!</p>
    </div>
  </div>
</section>
<?php if (isset($_GET['add']) && $_GET['add'] === 'success'): ?>
<div class="position-fixed top-0 end-0 p-3" style="z-index: 1055">
  <div id="liveToast" class="toast align-items-center text-bg-success border-0 show" role="alert">
    <div class="d-flex">
      <div class="toast-body">
        ✅ Buku berhasil ditambahkan ke keranjang!
      </div>
      <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
    </div>
  </div>
</div>
<?php endif; ?>

<?php
include 'extends/footer.php';
?>


