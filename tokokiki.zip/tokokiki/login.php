<?php
session_start();
include('extends/navbar.php');
include('config/koneksi.php'); // Menghubungkan dengan database
$notif = "";
if (isset($_SESSION['notif'])) {
    $notif = $_SESSION['notif'];
    unset($_SESSION['notif']);
}
// Cek jika sudah login, arahkan ke halaman yang sesuai
if (isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}

if (isset($_GET['status'])) {
    $status = $_GET['status'];
    $message = "";
    $alertClass = "";

    if ($status == "empty_field") {
        $message = "Username dan password harus diisi.";
        $alertClass = "alert-warning";
    } elseif ($status == "invalid_credentials") {
        $message = "Username atau password salah.";
        $alertClass = "alert-danger";
    }
}
?>
<?php if (!empty($notif)): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?= htmlspecialchars($notif); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>


    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card shadow-sm">
                    <div class="card-header bg-primary text-white text-center">
                        <h3>Login</h3>
                    </div>
                    <div class="card-body">
                        <!-- Menampilkan pesan error jika ada -->
                        <?php if(isset($message)): ?>
                            <div class="alert <?php echo $alertClass; ?> alert-dismissible fade show" role="alert">
                                <?php echo $message; ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php endif; ?>

                        <!-- Form Login -->
                        <form action="login_process.php" method="POST">
                            <div class="mb-3">
                                <label for="username" class="form-label">Username</label>
                                <input type="text" class="form-control" id="username" name="username" required>
                            </div>
                            <div class="mb-3">
                                <label for="password" class="form-label">Password</label>
                                <input type="password" class="form-control" id="password" name="password" required>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">Login</button>
                        </form>
                        <p class="mt-3 text-center">Belum punya akun? <a href="register.php">Daftar di sini</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php
// Menyertakan footer dari folder 'extends'
include('extends/footer.php');
?>
