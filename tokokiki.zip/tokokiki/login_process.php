<?php
session_start();
include('config/koneksi.php'); // Menghubungkan dengan database

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil username dan password dari form
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    // Cek jika ada kolom yang kosong
    if (empty($username) || empty($password)) {
        header("Location: login.php?status=empty_field");
        exit();
    }

    // Query untuk mencari user berdasarkan username
    $query = "SELECT * FROM users WHERE username = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($user = mysqli_fetch_assoc($result)) {
        // Verifikasi password
        if (password_verify($password, $user['password'])) {
            // Set session untuk menyimpan data user
            $_SESSION['username'] = $user['username'];
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['role'] = $user['role'];

            // Redirect berdasarkan role
            if ($user['role'] == 'admin') {
                header("Location: admin/index.php");
            } else {
                header("Location: index.php");
            }
            exit();
        } else {
            // Jika password salah
            header("Location: login.php?status=invalid_credentials");
            exit();
        }
    } else {
        // Jika username tidak ditemukan
        header("Location: login.php?status=invalid_credentials");
        exit();
    }
} else {
    header("Location: login.php");
    exit();
}
