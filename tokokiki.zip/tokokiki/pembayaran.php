<?php
session_start();
include('config/koneksi.php');

if (!isset($_SESSION['user_id'])) {
    $_SESSION['notif'] = "Silakan login terlebih dahulu.";
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Ambil data checkout terakhir
$query_checkout = mysqli_query($conn, "
    SELECT * FROM checkout 
    WHERE user_id = $user_id 
    ORDER BY id_checkout DESC 
    LIMIT 1
");

$data_checkout = mysqli_fetch_assoc($query_checkout);


if (!$data_checkout) {
    $_SESSION['notif'] = "Data pembayaran tidak ditemukan.";
    header("Location: index.php");
    exit();
}

$metode = $data_checkout['metode_pembayaran'];
$total = $data_checkout['total_harga'];
// Daftar nomor rekening / e-wallet
$rekening = [
    "BRI" => ["nomor" => "1234567890", "nama_bank" => "Bank BRI"],
    "BCA" => ["nomor" => "9876543210", "nama_bank" => "Bank BCA"],
    "BSI" => ["nomor" => "5678901234", "nama_bank" => "Bank Syariah Indonesia"],
    "OVO" => ["nomor" => "081234567890", "nama_bank" => "OVO"],
    "Gopay" => ["nomor" => "081987654321", "nama_bank" => "Gopay"],
    "Dana" => ["nomor" => "08111222333", "nama_bank" => "Dana"],
];

$info = $rekening[$metode];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Instruksi Pembayaran</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container my-5">
        <h2>💰 Instruksi Pembayaran</h2>

        <div class="alert alert-success">
            <strong>Checkout berhasil!</strong><br>
            Silakan transfer sejumlah <strong>Rp <?= number_format($total, 0, ',', '.'); ?></strong>
            menggunakan metode pembayaran <strong><?= htmlspecialchars($metode); ?></strong>.
        </div>

        <div class="card mb-4">
            <div class="card-body">
                <h5 class="card-title">Detail Pembayaran</h5>
                <p class="card-text mb-1"><strong>Metode:</strong> <?= $info['nama_bank']; ?></p>
                <p class="card-text mb-1"><strong>Nomor Tujuan:</strong> <?= $info['nomor']; ?></p>
                <p class="card-text mb-1"><strong>Atas Nama:</strong> PT Toko Kiki Bersama</p>
                <p class="card-text"><strong>Total yang harus dibayar:</strong> Rp <?= number_format($total, 0, ',', '.'); ?></p>
            </div>
        </div>

        <div class="alert alert-warning">
            Setelah melakukan pembayaran, silakan kirim bukti transfer melalui WhatsApp ke <strong>0812-0000-0000</strong> atau upload melalui <a href="upload_bukti.php">halaman konfirmasi</a>.
        </div>

        <a href="upload_bukti.php" class="btn btn-primary">Kembali ke Beranda</a>
    </div>
</body>
</html>
