<?php
session_start();
include 'config/koneksi.php';

// Cek login
if (!isset($_SESSION['user_id'])) {
    $_SESSION['notif'] = "Silakan login terlebih dahulu.";
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Ambil data checkout terakhir
$query = mysqli_query($conn, "SELECT * FROM checkout WHERE user_id = $user_id ORDER BY id_checkout DESC LIMIT 1");
$checkout = mysqli_fetch_assoc($query);

if (!$checkout || empty($checkout['bukti_transfer'])) {
    $_SESSION['notif'] = "Data belum lengkap atau belum ada bukti transfer.";
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Pembayaran Berhasil - Toko Kiki</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: #f8f9fa;
    }

    .success-box {
      background-color: #ffffff;
      border-radius: 15px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
      padding: 40px;
    }

    .success-icon {
      font-size: 60px;
      color: #28a745;
    }

    .status-badge {
      font-size: 1rem;
      padding: 10px 15px;
      border-radius: 20px;
      background-color: #e6f7ec;
      color: #2e7d32;
      display: inline-block;
    }
  </style>
</head>
<body>

<div class="container py-5">
  <div class="row justify-content-center">
    <div class="col-md-8">
      <div class="success-box text-center">
        <div class="success-icon mb-3">
          ✅
        </div>
        <h2 class="text-success mb-3">Pembayaran Berhasil!</h2>
        <p class="lead">Terima kasih, <strong><?= htmlspecialchars($checkout['nama_penerima'] ?? 'Pelanggan') ?></strong>.</p>
        <p>Bukti pembayaran Anda telah kami terima. Tim kami akan segera memverifikasi dan mengirimkan pesanan Anda ke alamat berikut:</p>
        <blockquote class="blockquote">
          <p><?= htmlspecialchars($checkout['alamat_pengiriman']) ?></p>
        </blockquote>

        <div class="my-4">
          <span class="status-badge">Status: Menunggu Verifikasi Pembayaran</span>
        </div>

        <a href="index.php" class="btn btn-primary mt-3">Kembali ke Beranda</a>
      </div>
    </div>
  </div>
</div>

</body>
</html>
