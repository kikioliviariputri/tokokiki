<?php
session_start();
include('config/koneksi.php');

// Cek login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Ambil data penjualan berdasarkan user
$query = mysqli_query($conn, "
    SELECT 
        p.id_penjualan,
        p.tanggal_penjualan,
        p.total_harga,
        p.status_pembayaran,
        p.status_pengiriman,
        pr.nama_buku
    FROM penjualan p
    JOIN produk pr ON p.id_buku = pr.id_buku
    WHERE p.user_id = $user_id
    ORDER BY p.tanggal_penjualan DESC
");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Pesanan Saya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .badge-status {
            padding: 6px 10px;
            border-radius: 12px;
            font-size: 0.8rem;
        }
        .belum_dibayar { background-color: #ffc107; color: #000; }
        .sudah_dibayar { background-color: #198754; color: #fff; }
        .belum_dikirim { background-color: #dc3545; color: #fff; }
        .dikirim { background-color: #0d6efd; color: #fff; }
        .selesai { background-color: #20c997; color: #fff; }
    </style>
</head>
<body>
<div class="container my-5">
    <h2>📋 Pesanan Saya</h2>

    <?php if (isset($_SESSION['notif'])): ?>
        <div class="alert alert-info"><?= $_SESSION['notif']; unset($_SESSION['notif']); ?></div>
    <?php endif; ?>

    <table class="table table-bordered table-hover mt-4">
        <thead class="table-light">
            <tr>
                <th>#</th>
                <th>Tanggal</th>
                <th>Nama Buku</th>
                <th>Total Harga</th>
                <th>Status Pembayaran</th>
                <th>Status Pengiriman</th>
            </tr>
        </thead>
        <tbody>
        <?php if (mysqli_num_rows($query) > 0): ?>
            <?php $no = 1; while ($row = mysqli_fetch_assoc($query)): ?>
                <tr>
                    <td><?= $no++; ?></td>
                    <td><?= date('d M Y H:i', strtotime($row['tanggal_penjualan'])); ?></td>
                    <td><?= htmlspecialchars($row['nama_buku']) ?></td>
                    <td>Rp <?= number_format($row['total_harga'], 0, ',', '.'); ?></td>
                    <td>
                        <span class="badge-status <?= str_replace(' ', '_', strtolower($row['status_pembayaran'])) ?>">
                            <?= ucfirst($row['status_pembayaran']) ?>
                        </span>
                    </td>
                    <td>
                        <span class="badge-status <?= str_replace(' ', '_', strtolower($row['status_pengiriman'])) ?>">
                            <?= ucfirst($row['status_pengiriman']) ?>
                        </span>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="6" class="text-center">Belum ada pesanan.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
</body>
</html>
