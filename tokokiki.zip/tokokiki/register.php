<?php
// Memanggil navbar dan footer yang ada di folder 'extends'
include('extends/navbar.php');

// Cek apakah ada pesan status
if(isset($_GET['status'])) {
    $status = $_GET['status'];
    $message = "";
    $alertClass = "";

    // Menentukan pesan dan tipe alert berdasarkan status
    if($status == "success") {
        $message = "Registrasi berhasil! Silakan login.";
        $alertClass = "alert-success";  // Alert hijau
    } elseif($status == "error") {
        $message = "Terjadi kesalahan, silakan coba lagi!";
        $alertClass = "alert-danger";  // Alert merah
    } elseif($status == "password_mismatch") {
        $message = "Password dan konfirmasi password tidak cocok.";
        $alertClass = "alert-warning";  // Alert kuning
    } elseif($status == "empty_field") {
        $message = "Semua kolom harus diisi.";
        $alertClass = "alert-warning";  // Alert kuning
    } elseif($status == "username_exists") {
        $message = "Username sudah terdaftar, silakan gunakan username lain.";
        $alertClass = "alert-danger";  // Alert merah
    } elseif($status == "email_exists") {
        $message = "Email sudah terdaftar, silakan gunakan email lain.";
        $alertClass = "alert-danger";  // Alert merah
    }
}
?>

<div class="container my-5">
  <div class="row justify-content-center">
    <div class="col-md-6">
      <div class="card shadow-sm">
        <div class="card-header bg-primary text-white text-center">
          <h3>Register</h3>
        </div>
        <div class="card-body">
          
          <!-- Menampilkan Alert jika ada pesan error atau success -->
          <?php if(isset($message)): ?>
            <div class="alert <?php echo $alertClass; ?> alert-dismissible fade show" role="alert">
              <?php echo $message; ?>
              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
          <?php endif; ?>

          <!-- Formulir Register -->
          <form action="register_process.php" method="POST">
            <!-- Username -->
            <div class="mb-3">
              <label for="username" class="form-label">Username</label>
              <input type="text" class="form-control" id="username" name="username" required>
            </div>
            
            <!-- Email -->
            <div class="mb-3">
              <label for="email" class="form-label">Email Address</label>
              <input type="email" class="form-control" id="email" name="email" required>
            </div>
            
            <div class="mb-3">
              <label for="fullname" class="form-label">Full Name</label>
              <input type="text" class="form-control" id="fullname" name="fullname" required>
            </div>

            <!-- Password -->
            <div class="mb-3">
              <label for="password" class="form-label">Password</label>
              <input type="password" class="form-control" id="password" name="password" required>
            </div>
            
            <!-- Confirm Password -->
            <div class="mb-3">
              <label for="confirm_password" class="form-label">Confirm Password</label>
              <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
            </div>
            
            <!-- Submit Button -->
            <button type="submit" class="btn btn-primary w-100">Register</button>
          </form>

          <p class="mt-3 text-center">Already have an account? <a href="login.php">Login here</a></p>
        </div>
      </div>
    </div>
  </div>
</div>

<?php
// Menyertakan footer dari folder 'extends'
include('extends/footer.php');
?>
