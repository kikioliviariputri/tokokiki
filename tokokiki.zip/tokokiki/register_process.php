<?php
// Koneksi ke database
include('config/koneksi.php');

if($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Validasi apakah semua field diisi
    if(empty($username) || empty($email) || empty($password) || empty($confirm_password)) {
        header("Location: register.php?status=empty_field");
        exit();
    }

    // Validasi kecocokan password
    if($password !== $confirm_password) {
        header("Location: register.php?status=password_mismatch");
        exit();
    }

    // Mengecek apakah username sudah terdaftar
    $checkUsername = mysqli_query($conn, "SELECT * FROM users WHERE username='$username'");
    if(mysqli_num_rows($checkUsername) > 0) {
        header("Location: register.php?status=username_exists");
        exit();
    }

    // Mengecek apakah email sudah terdaftar
    $checkEmail = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");
    if(mysqli_num_rows($checkEmail) > 0) {
        header("Location: register.php?status=email_exists");
        exit();
    }

    // Hash password
    $password_hashed = password_hash($password, PASSWORD_DEFAULT);

    // Simpan data ke database
    $sql = "INSERT INTO users (username, email, password,fullname) VALUES ('$username', '$email', '$password_hashed', '$fullname')";
    if(mysqli_query($conn, $sql)) {
        // Redirect ke halaman register dengan status success
        header("Location: register.php?status=success");
    } else {
        // Jika gagal, redirect dengan status error
        header("Location: register.php?status=error");
    }
}
?>
