<?php
session_start();
include 'config/koneksi.php';

// Cek login
if (!isset($_SESSION['user_id'])) {
    $_SESSION['notif'] = "Silakan login terlebih dahulu.";
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Ambil data checkout terakhir
$query = mysqli_query($conn, "SELECT * FROM checkout WHERE user_id = $user_id ORDER BY id_checkout DESC LIMIT 1");
$checkout = mysqli_fetch_assoc($query);

if (!$checkout) {
    $_SESSION['notif'] = "Data checkout tidak ditemukan.";
    header("Location: index.php");
    exit();
}

$id_checkout = $checkout['id_checkout'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_FILES['bukti']) && $_FILES['bukti']['error'] == 0) {
        $target_dir = "bukti_transfer/";
        $ext = pathinfo($_FILES['bukti']['name'], PATHINFO_EXTENSION);
        $filename = "bukti_" . time() . "." . $ext;
        $target_file = $target_dir . $filename;

        if (move_uploaded_file($_FILES['bukti']['tmp_name'], $target_file)) {
            // Update data checkout
            mysqli_query($conn, "UPDATE checkout SET bukti_transfer = '$filename' WHERE id_checkout = $id_checkout");

            $_SESSION['notif'] = "Bukti transfer berhasil diunggah!";
            header("Location: pembayaran_sukses.php");
            exit();
        } else {
            $error = "Upload gagal, coba lagi.";
        }
    } else {
        $error = "Pilih file terlebih dahulu.";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Upload Bukti Transfer</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container my-5">
    <h3>📤 Upload Bukti Pembayaran</h3>

    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data">
        <div class="mb-3">
            <label for="bukti" class="form-label">Unggah Bukti Transfer (jpg/png/pdf)</label>
            <input type="file" name="bukti" id="bukti" class="form-control" required accept=".jpg,.jpeg,.png,.pdf">
        </div>
        <button type="submit" class="btn btn-primary">Kirim Bukti</button>
        <a href="index.php" class="btn btn-secondary">Batal</a>
    </form>
</div>
</body>
</html>
